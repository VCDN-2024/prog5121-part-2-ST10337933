/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package easykanban;

import static org.junit.Assert.*;
import org.junit.Test;

public class EasyKanBanTest {

    @Test //(geeksforgeeks,2024)
    public void testUsernameCorrectlyFormatted() {
        EasyKanBan.Login login = new EasyKanBan.Login();
        assertTrue(login.checkUserName("kyl_1"));
    }

    @Test //(geeksforgeeks,2024)
    public void testUsernameIncorrectlyFormatted() {
        EasyKanBan.Login login = new EasyKanBan.Login();
        assertFalse(login.checkUserName("kyle!!!!!!!"));
    }

    @Test //(geeksforgeeks,2024)
    public void testPasswordMeetsComplexity() {
        EasyKanBan.Login login = new EasyKanBan.Login();
        assertTrue(login.checkPasswordComplexity("Ch&&sec@ke99!"));
    }

    @Test //(geeksforgeeks,2024)
    public void testPasswordDoesNotMeetComplexity() {
        EasyKanBan.Login login = new EasyKanBan.Login();
        assertFalse(login.checkPasswordComplexity("password"));
    }

    @Test //(geeksforgeeks,2024)
    public void testTaskDescriptionSuccess() {
        EasyKanBan.Task task = new EasyKanBan.Task("Login Feature", 0, "Create Login to authenticate users", "Robyn Harrison", 8, "To Do");
        assertTrue(task.checkTaskDescription());
        assertEquals("Task successfully captured", task.checkTaskDescription() ? "Task successfully captured" : "Please enter a task description of less than 50 characters");
    }

    @Test //(geeksforgeeks,2024)
    public void testTaskDescriptionFailure() {
        EasyKanBan.Task task = new EasyKanBan.Task("Login Feature", 0, "This description is definitely more than fifty characters long, which should fail the test", "Robyn Harrison", 8, "To Do");
        assertFalse(task.checkTaskDescription());
        assertEquals("Please enter a task description of less than 50 characters", task.checkTaskDescription() ? "Task successfully captured" : "Please enter a task description of less than 50 characters");
    }

    @Test //(geeksforgeeks,2024)
    public void testTaskIDCorrect() {
        EasyKanBan.Task task = new EasyKanBan.Task("Add Task Feature", 1, "Create Add Task feature to add task users", "Mike Smith", 10, "Doing");
        assertEquals("AD:1:ITH", task.createTaskID());
    }

    @Test //(geeksforgeeks,2024)
    public void testTaskIDsInLoop() {
        EasyKanBan.Task[] tasks = new EasyKanBan.Task[5];
        tasks[0] = new EasyKanBan.Task("Create", 0, "Description0", "Mike", 10, "To Do");
        tasks[1] = new EasyKanBan.Task("Create", 1, "Description1", "Richard", 12, "Doing");
        tasks[2] = new EasyKanBan.Task("Create", 2, "Description2", "Martha", 55, "Done");
        tasks[3] = new EasyKanBan.Task("Create", 3, "Description3", "Amanda", 11, "To Do");
        tasks[4] = new EasyKanBan.Task("Create", 4, "Description4", "Jonathan", 1, "Doing");

        String[] expectedIDs = {"CR:0:IKE", "CR:1:ARD", "CR:2:THA", "CR:3:NDA", "CR:4:HAN"};

        for (int i = 0; i < tasks.length; i++) {
            assertEquals(expectedIDs[i], tasks[i].createTaskID());
        }
    }

    @Test //(geeksforgeeks,2024)
    public void testTotalHoursCorrect() {
        EasyKanBan.Task[] tasks = new EasyKanBan.Task[2];
        tasks[0] = new EasyKanBan.Task("Login Feature", 0, "Create Login to authenticate users", "Robyn Harrison", 8, "To Do");
        tasks[1] = new EasyKanBan.Task("Add Task Feature", 1, "Create Add Task feature to add task users", "Mike Smith", 10, "Doing");
        assertEquals(18, EasyKanBan.Task.returnTotalHours(tasks));
    }

    @Test //(geeksforgeeks,2024)
    public void testTotalHoursMultipleTasks() {
        EasyKanBan.Task[] tasks = new EasyKanBan.Task[5];
        tasks[0] = new EasyKanBan.Task("Task1", 0, "Description1", "Dev1", 10, "To Do");
        tasks[1] = new EasyKanBan.Task("Task2", 1, "Description2", "Dev2", 12, "Doing");
        tasks[2] = new EasyKanBan.Task("Task3", 2, "Description3", "Dev3", 55, "Done");
        tasks[3] = new EasyKanBan.Task("Task4", 3, "Description4", "Dev4", 11, "To Do");
        tasks[4] = new EasyKanBan.Task("Task5", 4, "Description5", "Dev5", 1, "Doing");
        assertEquals(89, EasyKanBan.Task.returnTotalHours(tasks));
    }
}


/* CODE ATTRIBUTES
the refernece used in this unit test is mrs Fatimas video
//https://youtu.be/sFTbCVnUbLo?si=_5laLjZNENT4XAyj
geeksforgeeks, 2024, unit testiong from: https://www.geeksforgeeks.org/unit-testing-software-testing/
*/