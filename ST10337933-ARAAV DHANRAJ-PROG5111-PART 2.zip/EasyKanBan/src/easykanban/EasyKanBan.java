/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package easykanban;

/**
 *
 * @author lab_services_student
 */

import java.util.regex.Matcher; //(w3schools,1998)
import java.util.regex.Pattern; //(w3schools,1998)
import javax.swing.*;

public class EasyKanBan {

    static class Login {
        private String username;
        private String password;
        private boolean isLoggedIn; //(w3schools,1998)

        public boolean checkUserName(String username) {
            Pattern pattern = Pattern.compile("^[a-zA-Z0-9_]{1,5}$"); //(w3schools,1998)
            Matcher matcher = pattern.matcher(username); //(w3schools,1998)
            if (matcher.find() && username.contains("_")) { //(w3schools,1998)
                this.username = username;
                return true;
            }
            //the above code is used to check if the entered username meets the criteria
            
            return false;
        }
//its set to false if its not in the criteria
        
        
        public boolean checkPasswordComplexity(String password) { //(w3schools,1998)
            if (password.length() >= 8 &&
                password.matches(".*[A-Z].*") &&
                password.matches(".*\\d.*") &&
                password.matches(".*[!@#$%^&*].*")) {
                this.password = password;
                return true;
            }
     //this is the same but its now checking if the password meets the criteria       
            
            return false;
        }

        //same as above if it does not it is set to false 
        
        
        public String registerUser(String username, String password) {
            if (!checkUserName(username)) {
                return "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length.";
            }
            
            
            if (!checkPasswordComplexity(password)) {
                return "Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number and a special character.";
            }
            
            return "User successfully registered";
        }

        //the code below is used to register the user with their i formation entered if it meets the criteria
        public boolean loginUser(String username, String password) { //(w3schools,1998)
            if (this.username.equals(username) && this.password.equals(password)) {
                this.isLoggedIn = true;
                
                return true;
            }
            
            return false;
        }
        
        //if the user logs in with differnet information it is once again set to false

        public String returnLoginStatus() {
            if (this.isLoggedIn) {
                return "Welcome " + this.username + ", it is great to see you again.";
            }
            //the above code displays a welcome message if the user uses the correct information provided 
            
            
            return "Username or password incorrect, please try again";
        }
        
        //if no an error message will display telling the user that the username or password is incorrect
    }

    static class Task {
        private String taskName;
        private int taskNumber;
        private String taskDescription;
        private String developer;
        private int taskDuration;
        private String taskStatus;
        private String taskId;

        public Task(String taskName, int taskNumber, String taskDescription, String developer, int taskDuration, String taskStatus) {
            this.taskName = taskName;
            this.taskNumber = taskNumber;
            this.taskDescription = taskDescription;
            this.developer = developer;
            this.taskDuration = taskDuration;
            this.taskStatus = taskStatus;
            this.taskId = createTaskID();
        }

        public boolean checkTaskDescription() { //(w3schools,1998)
            return this.taskDescription.length() <= 50;
        }
        //the above code is used to check if the task description is less the equal to 50 words
        
        

        public String createTaskID() {
            return this.taskName.substring(0, 2).toUpperCase() + ":" + this.taskNumber + ":" + this.developer.substring(this.developer.length() - 3).toUpperCase();
        }
        //used to create a unique task id

        public String printTaskDetails() {
            return String.format("Task Status: %s\nDeveloper Details: %s\nTask Number: %d\nTask Name: %s\nTask Description: %s\nTask ID: %s\nDuration: %d hours",
                    this.taskStatus, this.developer, this.taskNumber, this.taskName, this.taskDescription, this.taskId, this.taskDuration);
        }
        //to display task details
        

        public static int returnTotalHours(Task[] tasks) {
            int totalHours = 0;
            for (Task task : tasks) {
                totalHours += task.taskDuration;
            }
            //this allows the sytem to reture the total number of hours
            
            return totalHours;
        }
    }

    public static void main(String[] args) {
        Login loginSystem = new Login();

        // User registration
        String username = JOptionPane.showInputDialog("Enter username:"); //(javatpoint,N/A)
        
        String password = JOptionPane.showInputDialog("Enter password:"); //(javatpoint,N/A)
        
        String registrationMessage = loginSystem.registerUser(username, password);
        
        JOptionPane.showMessageDialog(null, registrationMessage); //(javatpoint,N/A)

        // User login
        String loginUsername = JOptionPane.showInputDialog("Enter username to login:");
        
        
        String loginPassword = JOptionPane.showInputDialog("Enter password to login:");

        if (loginSystem.loginUser(loginUsername, loginPassword)) {
            
            JOptionPane.showMessageDialog(null, loginSystem.returnLoginStatus()); //(javatpoint,N/A)
            
            
            JOptionPane.showMessageDialog(null, "Welcome to EasyKanban"); //(javatpoint,N/A)

            
            //the below code is the menu loop
            while (true) {
                String[] options = {"Add Tasks", "Show Report", "Quit"};
                int choice = JOptionPane.showOptionDialog(null, "Choose an option", "Menu",
                        JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]); //(javatpoint,N/A)

                switch (choice) {
                    case 0: // Add Tasks
                        int numTasks = Integer.parseInt(JOptionPane.showInputDialog("How many tasks do you want to add?")); //(javatpoint,N/A)

                        Task[] tasks = new Task[numTasks];
                        for (int i = 0; i < numTasks; i++) {
                            String taskName = JOptionPane.showInputDialog("Enter task name:"); //(javatpoint,N/A)
                            //asks user for task name
                            
                            String taskDescription = JOptionPane.showInputDialog("Enter task description:"); //(javatpoint,N/A)
                            while (taskDescription.length() > 50) 
                            {
                                taskDescription = JOptionPane.showInputDialog("Please enter a task description of less than 50 characters:"); //(javatpoint,N/A)
                            }
                            //asks user for task decription
                            
                            String developer = JOptionPane.showInputDialog("Enter developer:"); //(javatpoint,N/A)
                            //asks user to enter the developer or author
                            
                            int taskDuration = Integer.parseInt(JOptionPane.showInputDialog("Enter task duration in hours:")); //(javatpoint,N/A)
                            
                            String taskStatus = JOptionPane.showInputDialog("Enter task status (To Do, Done, Doing):"); //(javatpoint,N/A)
//aks the user for the stauts of the task
                            tasks[i] = new Task(taskName, i, taskDescription, developer, taskDuration, taskStatus);
                            JOptionPane.showMessageDialog(null, tasks[i].printTaskDetails()); //(javatpoint,N/A)
                        }
                        JOptionPane.showMessageDialog(null, "Total Hours: " + Task.returnTotalHours(tasks)); //(javatpoint,N/A)
                        break;
//this claculates and shows the total amount of hours 
                    case 1: // Show Report
                        JOptionPane.showMessageDialog(null, "Coming Soon"); //(javatpoint,N/A)
                        break;
//the user is presented with options to either add task , show the report and to close or cancel the system
                        
                        
                    case 2: // Quit
                        JOptionPane.showMessageDialog(null, "Thank you for using EasyKanban!"); //(javatpoint,N/A)
                        System.exit(0);
                        break;
//lastly a display message tells the user goodbye
                        
                        
                    default:
                        break;
                }
            }
        } else {
            JOptionPane.showMessageDialog(null, "Username or password incorrect, please try again"); //(javatpoint,N/A)
        }
    }
}

/* CODE ATTRIBUTIONS
Java Regular expressions, w3scools, 1998, from: https://www.w3schools.com/java/java_regex.asp
Java Boolean, w3schools, 1998, from: https://www.w3schools.com/java/java_booleans.asp
JOption, javatpoint, N/A from: https://www.javatpoint.com/java-joptionpane

*/